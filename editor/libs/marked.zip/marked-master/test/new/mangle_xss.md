---
sanatize: true
mangle: false
---
<<svg/onload="alert(1)"//@x>

<bar"onclick="alert('XSS')"@foo>
