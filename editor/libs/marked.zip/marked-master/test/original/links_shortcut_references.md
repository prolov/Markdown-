---
pedantic: true
---

This is the [simple case].

[simple case]: /simple



This one has a [line
break].

This one has a [line 
break] with a line-ending space.

[line break]: /foo


[this] [that] and the [other]

[this]: /this
[that]: /that
[other]: /other
